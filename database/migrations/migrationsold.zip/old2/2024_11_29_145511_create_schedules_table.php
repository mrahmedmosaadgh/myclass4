<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('schedules', function (Blueprint $table) {
            $table->id();

            // Foreign keys
            $table->foreignId('copy_id')->constrained('schedule_copies')->onDelete('cascade');
            $table->foreignId('cst_id')->nullable()->constrained('classroom_subject_teachers')->onDelete('set null');
            $table->foreignId('school_id')->constrained('schools')->onDelete('cascade');
            // $table->foreignId('grade_id')->constrained('grades')->onDelete('cascade');
            // $table->foreignId('classroom_id')->constrained('classrooms')->onDelete('cascade');
            // $table->foreignId('subject_id')->constrained('subjects')->onDelete('cascade');
            // $table->foreignId('teacher_id')->nullable()->constrained('teachers')->onDelete('set null');
            $table->foreignId('teacher_substitute_id')->nullable()->constrained('teachers')->onDelete('set null');
            $table->foreignId('co_teacher_id')->nullable()->constrained('teachers')->onDelete('set null');
            $table->foreignId('period_detail_id')->nullable()->constrained('period_details')->onDelete('set null');

            // Schedule timing information
            $table->unsignedTinyInteger('day')->nullable();
            $table->unsignedTinyInteger('week')->nullable();
            $table->unsignedTinyInteger('semester')->nullable();
            $table->unsignedTinyInteger('period_order')->nullable()->comment('Sequence number');

            // Location and display information
            $table->string('place', 120)->nullable()->comment('Physical location or classroom');
            $table->string('color_custom', 7)->nullable()->comment('Custom color for UI display (hex format: #RRGGBB)');

            // Status
            $table->boolean('active')->default(true)->comment('Whether this schedule is currently active');
            $table->text('notes')->nullable()->comment('Additional notes or comments');

            // Timestamps and soft deletes
            $table->timestamps();
            $table->softDeletes();

            // Indexes for better performance
            $table->index(['school_id', 'grade_id', 'classroom_id']);
            $table->index(['school_id', 'day', 'period_order']);
            $table->index(['copy_id', 'active']);
            $table->index(['teacher_id', 'day']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('schedules');
    }
};


